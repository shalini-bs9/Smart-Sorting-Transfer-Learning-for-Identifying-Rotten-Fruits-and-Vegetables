import React, { useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Camera, Square, RotateCcw, X } from 'lucide-react';

interface CameraCaptureProps {
  onCapture: (imageData: string) => void;
  disabled?: boolean;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, disabled }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'environment' // Use back camera on mobile
        }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsStreaming(true);
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
      setError('Unable to access camera. Please check permissions.');
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsStreaming(false);
    }
  }, []);

  const captureImage = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    const imageData = canvas.toDataURL('image/jpeg', 0.8);
    setCapturedImage(imageData);
    onCapture(imageData);
    stopCamera();
  }, [onCapture, stopCamera]);

  const retakePhoto = useCallback(() => {
    setCapturedImage(null);
    startCamera();
  }, [startCamera]);

  const clearCapture = useCallback(() => {
    setCapturedImage(null);
    stopCamera();
  }, [stopCamera]);

  return (
    <div className="w-full">
      <canvas ref={canvasRef} className="hidden" />
      
      {error && (
        <motion.div
          className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <p className="text-red-800 text-sm">{error}</p>
        </motion.div>
      )}

      {!isStreaming && !capturedImage && (
        <motion.div
          className="text-center p-8 border-2 border-dashed border-gray-300 rounded-xl"
          whileHover={!disabled ? { scale: 1.02 } : {}}
          whileTap={!disabled ? { scale: 0.98 } : {}}
        >
          <div className={`mx-auto w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
            disabled ? 'bg-gray-200' : 'bg-blue-100'
          }`}>
            <Camera className={`h-8 w-8 ${disabled ? 'text-gray-400' : 'text-blue-600'}`} />
          </div>
          
          <h3 className={`text-lg font-semibold mb-2 ${disabled ? 'text-gray-400' : 'text-gray-900'}`}>
            Use Camera
          </h3>
          <p className={`text-sm mb-4 ${disabled ? 'text-gray-400' : 'text-gray-600'}`}>
            Capture a photo of your produce for analysis
          </p>
          
          <button
            onClick={startCamera}
            disabled={disabled}
            className={`px-6 py-3 rounded-lg font-medium transition-colors ${
              disabled
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            Start Camera
          </button>
        </motion.div>
      )}

      {isStreaming && (
        <motion.div
          className="relative bg-black rounded-xl overflow-hidden"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-64 object-cover"
          />
          
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-4">
            <button
              onClick={captureImage}
              className="bg-white p-3 rounded-full hover:bg-gray-100 transition-colors shadow-lg"
            >
              <Square className="h-6 w-6 text-gray-900" />
            </button>
            
            <button
              onClick={stopCamera}
              className="bg-red-500 p-3 rounded-full hover:bg-red-600 transition-colors shadow-lg"
            >
              <X className="h-6 w-6 text-white" />
            </button>
          </div>
        </motion.div>
      )}

      {capturedImage && (
        <motion.div
          className="relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <div className="relative bg-gray-100 rounded-xl overflow-hidden">
            <img
              src={capturedImage}
              alt="Captured produce"
              className="w-full h-64 object-cover"
            />
          </div>
          
          <div className="mt-4 flex justify-center space-x-4">
            <button
              onClick={retakePhoto}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2"
            >
              <RotateCcw className="h-4 w-4" />
              <span>Retake</span>
            </button>
            
            <button
              onClick={clearCapture}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
            >
              <X className="h-4 w-4" />
              <span>Clear</span>
            </button>
          </div>
          
          <div className="mt-2 text-center">
            <p className="text-sm text-gray-600">
              Photo captured. Analysis will begin automatically.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default CameraCapture;