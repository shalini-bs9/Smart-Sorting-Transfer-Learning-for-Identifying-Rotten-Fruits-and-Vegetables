import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Zap, Eye, Cpu } from 'lucide-react';

const ProcessingAnimation: React.FC = () => {
  const steps = [
    { icon: Eye, label: 'Analyzing Image', color: 'blue' },
    { icon: Brain, label: 'Processing AI Model', color: 'green' },
    { icon: Cpu, label: 'Computing Results', color: 'purple' },
    { icon: Zap, label: 'Finalizing Analysis', color: 'orange' }
  ];

  return (
    <div className="text-center py-8">
      <motion.div
        className="mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          Analyzing Your Produce
        </h3>
        <p className="text-gray-600">
          Our AI is examining the image for quality indicators...
        </p>
      </motion.div>

      {/* Processing Steps */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {steps.map((step, index) => (
          <motion.div
            key={index}
            className="flex flex-col items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.2 }}
          >
            <motion.div
              className={`bg-${step.color}-100 p-4 rounded-full mb-3`}
              animate={{
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: index * 0.3
              }}
            >
              <step.icon className={`h-6 w-6 text-${step.color}-600`} />
            </motion.div>
            <span className="text-sm font-medium text-gray-700">
              {step.label}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Progress Bar */}
      <div className="max-w-md mx-auto">
        <div className="bg-gray-200 rounded-full h-2 overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-blue-500 via-green-500 to-purple-500"
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Processing... This may take a few seconds
        </p>
      </div>

      {/* Floating Particles */}
      <div className="relative h-20 overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-green-400 rounded-full opacity-60"
            initial={{
              x: Math.random() * 400,
              y: 80,
              opacity: 0
            }}
            animate={{
              y: -20,
              opacity: [0, 1, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.3,
              ease: "easeOut"
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default ProcessingAnimation;