import React from 'react';
import { motion } from 'framer-motion';
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  Target, 
  Award,
  TrendingUp,
  Info,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';

interface AnalysisResult {
  classification: 'fresh' | 'rotten' | 'uncertain' | 'error';
  confidence: number;
  details?: {
    freshness_score: number;
    decay_indicators: string[];
    quality_grade: string;
    recommendations: string[];
    produce_type: string;
  };
  processing_time: number;
  timestamp: string;
  error?: string;
}

interface ResultsDisplayProps {
  results: AnalysisResult;
  onReset: () => void;
  onFeedback?: (feedback: 'correct' | 'incorrect') => void;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results, onReset, onFeedback }) => {
  const getStatusIcon = () => {
    switch (results.classification) {
      case 'fresh':
        return <CheckCircle className="h-8 w-8 text-green-500" />;
      case 'rotten':
        return <XCircle className="h-8 w-8 text-red-500" />;
      case 'uncertain':
        return <AlertTriangle className="h-8 w-8 text-yellow-500" />;
      default:
        return <XCircle className="h-8 w-8 text-gray-500" />;
    }
  };

  const getStatusColor = () => {
    switch (results.classification) {
      case 'fresh':
        return 'green';
      case 'rotten':
        return 'red';
      case 'uncertain':
        return 'yellow';
      default:
        return 'gray';
    }
  };

  const getStatusText = () => {
    switch (results.classification) {
      case 'fresh':
        return 'Fresh Produce Detected';
      case 'rotten':
        return 'Rotten Produce Detected';
      case 'uncertain':
        return 'Quality Uncertain';
      default:
        return 'Analysis Error';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-600';
    if (confidence >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getFreshnessColor = (score: number) => {
    if (score >= 0.7) return 'from-green-500 to-green-600';
    if (score >= 0.4) return 'from-yellow-500 to-orange-500';
    return 'from-red-500 to-red-600';
  };

  if (results.error) {
    return (
      <motion.div
        className="text-center p-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-800 mb-2">Analysis Failed</h3>
          <p className="text-red-600">{results.error}</p>
        </div>
      </motion.div>
    );
  }

  const statusColor = getStatusColor();

  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* Main Result */}
      <div className={`bg-${statusColor}-50 border border-${statusColor}-200 rounded-xl p-6 text-center`}>
        <div className="flex justify-center mb-4">
          {getStatusIcon()}
        </div>
        
        <h3 className={`text-2xl font-bold text-${statusColor}-800 mb-2`}>
          {getStatusText()}
        </h3>
        
        {results.details && (
          <p className={`text-${statusColor}-700 mb-4`}>
            {results.details.produce_type}
          </p>
        )}
        
        <div className="flex items-center justify-center space-x-4 text-sm">
          <div className="flex items-center space-x-1">
            <Target className={`h-4 w-4 text-${statusColor}-600`} />
            <span className={`${getConfidenceColor(results.confidence)} font-medium`}>
              {(results.confidence * 100).toFixed(1)}% Confidence
            </span>
          </div>
          
          <div className="flex items-center space-x-1">
            <Clock className={`h-4 w-4 text-${statusColor}-600`} />
            <span className={`text-${statusColor}-700`}>
              {results.processing_time}ms
            </span>
          </div>
        </div>

        {/* Confidence Bar */}
        <div className="mt-4">
          <div className="bg-white rounded-full h-2 overflow-hidden">
            <motion.div
              className={`h-full bg-gradient-to-r ${
                results.confidence >= 0.8 ? 'from-green-500 to-green-600' :
                results.confidence >= 0.6 ? 'from-yellow-500 to-orange-500' :
                'from-red-500 to-red-600'
              }`}
              initial={{ width: 0 }}
              animate={{ width: `${results.confidence * 100}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </div>
        </div>
      </div>

      {/* Detailed Results */}
      {results.details && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Quality Metrics */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <TrendingUp className="h-5 w-5 text-blue-500 mr-2" />
              Quality Metrics
            </h4>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">Freshness Score</span>
                  <span className="text-sm font-bold text-gray-900">
                    {(results.details.freshness_score * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="bg-gray-200 rounded-full h-3">
                  <motion.div
                    className={`h-full bg-gradient-to-r ${getFreshnessColor(results.details.freshness_score)} rounded-full`}
                    initial={{ width: 0 }}
                    animate={{ width: `${results.details.freshness_score * 100}%` }}
                    transition={{ duration: 1, delay: 0.2 }}
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Award className="h-5 w-5 text-yellow-500" />
                <span className="font-medium text-gray-900">{results.details.quality_grade}</span>
              </div>
            </div>
          </div>

          {/* Analysis Details */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Info className="h-5 w-5 text-purple-500 mr-2" />
              Analysis Details
            </h4>
            
            <div className="space-y-3">
              <div>
                <h5 className="text-sm font-medium text-gray-700 mb-2">Indicators</h5>
                <div className="space-y-1">
                  {results.details.decay_indicators.map((indicator, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <div className={`w-2 h-2 rounded-full ${
                        results.classification === 'fresh' ? 'bg-green-500' : 
                        results.classification === 'rotten' ? 'bg-red-500' : 'bg-yellow-500'
                      }`} />
                      <span className="text-gray-600">{indicator}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Recommendations */}
      {results.details?.recommendations && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h4 className="text-lg font-semibold text-blue-900 mb-4">Recommendations</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {results.details.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start space-x-2">
                <div className="bg-blue-500 rounded-full p-1 mt-0.5">
                  <div className="w-1 h-1 bg-white rounded-full" />
                </div>
                <span className="text-blue-800 text-sm">{recommendation}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* User Feedback */}
      {onFeedback && results.classification !== 'error' && (
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Was this analysis accurate?</h4>
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => onFeedback('correct')}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              <ThumbsUp className="h-4 w-4" />
              <span>Correct</span>
            </button>
            <button
              onClick={() => onFeedback('incorrect')}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              <ThumbsDown className="h-4 w-4" />
              <span>Incorrect</span>
            </button>
          </div>
        </div>
      )}

      {/* Timestamp */}
      <div className="text-center text-xs text-gray-500">
        Analysis completed at {new Date(results.timestamp).toLocaleString()}
      </div>
    </motion.div>
  );
};

export default ResultsDisplay;