import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import SortingApp from './pages/SortingApp';
import Dashboard from './pages/Dashboard';
import About from './pages/About';
import { AIProvider } from './context/AIContext';

function App() {
  return (
    <AIProvider>
      <Router>
        <div className="min-h-screen bg-white">
          <Header />
          <motion.main
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/app" element={<SortingApp />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/about" element={<About />} />
            </Routes>
          </motion.main>
        </div>
      </Router>
    </AIProvider>
  );
}

export default App;