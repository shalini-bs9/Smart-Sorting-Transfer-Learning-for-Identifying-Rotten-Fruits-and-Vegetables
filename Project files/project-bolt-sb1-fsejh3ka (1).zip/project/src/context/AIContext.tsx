import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { aiService, ImageAnalysisResult } from '../services/aiService';
import { firebaseService, AnalysisRecord } from '../services/firebaseService';

interface AIContextType {
  isModelLoaded: boolean;
  analyzeImage: (imageData: string) => Promise<AnalysisResult>;
  loadModel: () => Promise<void>;
  recentAnalyses: AnalysisRecord[];
  isLoading: boolean;
  modelLoadError: string | null;
}

interface AnalysisResult {
  classification: 'fresh' | 'rotten' | 'uncertain' | 'error';
  confidence: number;
  details?: {
    freshness_score: number;
    decay_indicators: string[];
    quality_grade: string;
    recommendations: string[];
    produce_type: string;
  };
  processing_time: number;
  timestamp: string;
  error?: string;
}

const AIContext = createContext<AIContextType | undefined>(undefined);

export const useAI = () => {
  const context = useContext(AIContext);
  if (!context) {
    throw new Error('useAI must be used within an AIProvider');
  }
  return context;
};

interface AIProviderProps {
  children: ReactNode;
}

export const AIProvider: React.FC<AIProviderProps> = ({ children }) => {
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [recentAnalyses, setRecentAnalyses] = useState<AnalysisRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [modelLoadError, setModelLoadError] = useState<string | null>(null);

  const loadModel = async () => {
    try {
      setIsLoading(true);
      setModelLoadError(null);
      await aiService.loadModel();
      setIsModelLoaded(true);
    } catch (error) {
      console.error('Failed to load model:', error);
      setIsModelLoaded(false);
      setModelLoadError(error instanceof Error ? error.message : 'Failed to load AI model');
    } finally {
      setIsLoading(false);
    }
  };

  const analyzeImage = async (imageData: string): Promise<AnalysisResult> => {
    const startTime = Date.now();
    
    if (!aiService.isModelLoaded()) {
      throw new Error('Model not loaded');
    }

    try {
      // Perform AI analysis
      const analysisResult: ImageAnalysisResult = await aiService.analyzeImage(imageData);
      
      // Convert base64 to blob for storage
      const response = await fetch(imageData);
      const blob = await response.blob();
      
      // Upload image to Firebase Storage
      const filename = `analysis_${Date.now()}.jpg`;
      const imageUrl = await firebaseService.uploadImage(blob, filename);
      
      // Prepare data for Firebase
      const analysisRecord: Omit<AnalysisRecord, 'id'> = {
        imageUrl,
        classification: analysisResult.classification,
        confidence: analysisResult.confidence,
        freshness_score: analysisResult.freshness_score,
        decay_indicators: analysisResult.decay_indicators,
        quality_grade: analysisResult.quality_grade,
        recommendations: analysisResult.recommendations,
        processing_time: Date.now() - startTime,
        timestamp: new Date() as any,
        produce_type: analysisResult.produce_type
      };
      
      // Save to Firebase
      await firebaseService.saveAnalysis(analysisRecord);
      
      // Update recent analyses
      const recent = await firebaseService.getRecentAnalyses(10);
      setRecentAnalyses(recent);
      
      const result: AnalysisResult = {
        classification: analysisResult.classification,
        confidence: analysisResult.confidence,
        details: {
          freshness_score: analysisResult.freshness_score,
          decay_indicators: analysisResult.decay_indicators,
          quality_grade: analysisResult.quality_grade,
          recommendations: analysisResult.recommendations,
          produce_type: analysisResult.produce_type
        },
        processing_time: Date.now() - startTime,
        timestamp: new Date().toISOString()
      };

      return result;
    } catch (error) {
      console.error('Analysis failed:', error);
      
      const result: AnalysisResult = {
        classification: 'error',
        confidence: 0,
        processing_time: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : 'Analysis failed'
      };
      
      return result;
    }
  };

  useEffect(() => {
    loadModel();
    
    // Load recent analyses
    firebaseService.getRecentAnalyses(10).then(setRecentAnalyses);
    
    // Set up real-time listener
    const unsubscribe = firebaseService.subscribeToAnalyses((analyses) => {
      setRecentAnalyses(analyses);
    });
    
    return () => unsubscribe();
  }, []);

  const value: AIContextType = {
    isModelLoaded,
    analyzeImage,
    loadModel,
    recentAnalyses,
    isLoading,
    modelLoadError
  };

  return (
    <AIContext.Provider value={value}>
      {children}
    </AIContext.Provider>
  );
};