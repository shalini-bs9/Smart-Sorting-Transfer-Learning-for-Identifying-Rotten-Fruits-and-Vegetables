import * as tf from '@tensorflow/tfjs';

export interface ImageAnalysisResult {
  classification: 'fresh' | 'rotten' | 'uncertain';
  confidence: number;
  freshness_score: number;
  decay_indicators: string[];
  quality_grade: string;
  recommendations: string[];
  produce_type: string;
}

class AIService {
  private model: tf.LayersModel | null = null;
  private isLoaded = false;

  async loadModel(): Promise<void> {
    try {
      // Load MobileNetV2 for transfer learning
      const mobilenet = await tf.loadLayersModel('https://tfhub.dev/google/tfjs-model/imagenet/mobilenet_v2_100_224/feature_vector/3/default/1', {
        fromTFHub: true
      });

      // Create a simple classification head
      const model = tf.sequential({
        layers: [
          tf.layers.inputLayer({ inputShape: [224, 224, 3] }),
          mobilenet,
          tf.layers.dense({ units: 128, activation: 'relu' }),
          tf.layers.dropout({ rate: 0.5 }),
          tf.layers.dense({ units: 64, activation: 'relu' }),
          tf.layers.dense({ units: 3, activation: 'softmax' }) // fresh, rotten, uncertain
        ]
      });

      this.model = model;
      this.isLoaded = true;
    } catch (error) {
      console.error('Failed to load model:', error);
      // Fallback to a simpler model for demo
      this.createFallbackModel();
    }
  }

  private createFallbackModel(): void {
    // Create a simple CNN for demonstration
    this.model = tf.sequential({
      layers: [
        tf.layers.conv2d({
          inputShape: [224, 224, 3],
          filters: 32,
          kernelSize: 3,
          activation: 'relu'
        }),
        tf.layers.maxPooling2d({ poolSize: 2 }),
        tf.layers.conv2d({ filters: 64, kernelSize: 3, activation: 'relu' }),
        tf.layers.maxPooling2d({ poolSize: 2 }),
        tf.layers.conv2d({ filters: 64, kernelSize: 3, activation: 'relu' }),
        tf.layers.flatten(),
        tf.layers.dense({ units: 64, activation: 'relu' }),
        tf.layers.dense({ units: 3, activation: 'softmax' })
      ]
    });
    this.isLoaded = true;
  }

  private async preprocessImage(imageData: string): Promise<tf.Tensor> {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        
        // Resize to 224x224
        canvas.width = 224;
        canvas.height = 224;
        ctx.drawImage(img, 0, 0, 224, 224);
        
        // Convert to tensor
        const tensor = tf.browser.fromPixels(canvas)
          .expandDims(0)
          .div(255.0); // Normalize to [0, 1]
        
        resolve(tensor);
      };
      img.src = imageData;
    });
  }

  private analyzeImageFeatures(imageData: string): {
    colorAnalysis: any;
    textureAnalysis: any;
    shapeAnalysis: any;
  } {
    // Simulate advanced image analysis
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    const img = new Image();
    
    return new Promise((resolve) => {
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        
        const imageDataArray = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = imageDataArray.data;
        
        // Color analysis
        let totalR = 0, totalG = 0, totalB = 0;
        let darkPixels = 0, brightPixels = 0;
        
        for (let i = 0; i < pixels.length; i += 4) {
          const r = pixels[i];
          const g = pixels[i + 1];
          const b = pixels[i + 2];
          
          totalR += r;
          totalG += g;
          totalB += b;
          
          const brightness = (r + g + b) / 3;
          if (brightness < 100) darkPixels++;
          if (brightness > 200) brightPixels++;
        }
        
        const pixelCount = pixels.length / 4;
        const avgR = totalR / pixelCount;
        const avgG = totalG / pixelCount;
        const avgB = totalB / pixelCount;
        
        const colorAnalysis = {
          averageColor: { r: avgR, g: avgG, b: avgB },
          darkPixelRatio: darkPixels / pixelCount,
          brightPixelRatio: brightPixels / pixelCount,
          colorVariance: this.calculateColorVariance(pixels)
        };
        
        resolve({
          colorAnalysis,
          textureAnalysis: this.analyzeTexture(pixels),
          shapeAnalysis: this.analyzeShape(pixels, canvas.width, canvas.height)
        });
      };
      img.src = imageData;
    }) as any;
  }

  private calculateColorVariance(pixels: Uint8ClampedArray): number {
    // Calculate color variance to detect spots and discoloration
    let variance = 0;
    const pixelCount = pixels.length / 4;
    
    for (let i = 0; i < pixels.length; i += 16) { // Sample every 4th pixel
      const r1 = pixels[i];
      const g1 = pixels[i + 1];
      const b1 = pixels[i + 2];
      
      if (i + 16 < pixels.length) {
        const r2 = pixels[i + 16];
        const g2 = pixels[i + 17];
        const b2 = pixels[i + 18];
        
        variance += Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2);
      }
    }
    
    return variance / (pixelCount / 4);
  }

  private analyzeTexture(pixels: Uint8ClampedArray): any {
    // Analyze texture patterns that indicate decay
    let edgeCount = 0;
    const threshold = 30;
    
    for (let i = 0; i < pixels.length - 4; i += 4) {
      const current = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
      const next = (pixels[i + 4] + pixels[i + 5] + pixels[i + 6]) / 3;
      
      if (Math.abs(current - next) > threshold) {
        edgeCount++;
      }
    }
    
    return {
      edgeDensity: edgeCount / (pixels.length / 4),
      smoothness: 1 - (edgeCount / (pixels.length / 4))
    };
  }

  private analyzeShape(pixels: Uint8ClampedArray, width: number, height: number): any {
    // Analyze shape irregularities
    const centerX = width / 2;
    const centerY = height / 2;
    let irregularityScore = 0;
    
    // Sample points around the center to detect shape distortions
    for (let angle = 0; angle < 360; angle += 10) {
      const x = centerX + Math.cos(angle * Math.PI / 180) * (width / 4);
      const y = centerY + Math.sin(angle * Math.PI / 180) * (height / 4);
      
      if (x >= 0 && x < width && y >= 0 && y < height) {
        const pixelIndex = (Math.floor(y) * width + Math.floor(x)) * 4;
        const brightness = (pixels[pixelIndex] + pixels[pixelIndex + 1] + pixels[pixelIndex + 2]) / 3;
        
        if (brightness < 50) { // Dark spots indicate potential rot
          irregularityScore++;
        }
      }
    }
    
    return {
      irregularityScore: irregularityScore / 36, // Normalize by number of sample points
      shapeIntegrity: 1 - (irregularityScore / 36)
    };
  }

  async analyzeImage(imageData: string): Promise<ImageAnalysisResult> {
    if (!this.isLoaded || !this.model) {
      throw new Error('Model not loaded');
    }

    try {
      // Preprocess image
      const tensor = await this.preprocessImage(imageData);
      
      // Analyze image features
      const features = await this.analyzeImageFeatures(imageData);
      
      // Get model prediction
      const prediction = this.model.predict(tensor) as tf.Tensor;
      const probabilities = await prediction.data();
      
      // Interpret results
      const freshProb = probabilities[0];
      const rottenProb = probabilities[1];
      const uncertainProb = probabilities[2];
      
      const maxProb = Math.max(freshProb, rottenProb, uncertainProb);
      let classification: 'fresh' | 'rotten' | 'uncertain';
      
      if (maxProb === freshProb) classification = 'fresh';
      else if (maxProb === rottenProb) classification = 'rotten';
      else classification = 'uncertain';

      // Enhanced analysis using image features
      const colorAnalysis = features.colorAnalysis;
      const textureAnalysis = features.textureAnalysis;
      const shapeAnalysis = features.shapeAnalysis;

      // Calculate freshness score based on multiple factors
      let freshnessScore = freshProb;
      
      // Adjust based on color analysis
      if (colorAnalysis.darkPixelRatio > 0.3) {
        freshnessScore *= 0.7; // Reduce score for dark spots
      }
      
      // Adjust based on texture
      if (textureAnalysis.smoothness < 0.5) {
        freshnessScore *= 0.8; // Reduce score for rough texture
      }
      
      // Adjust based on shape integrity
      if (shapeAnalysis.shapeIntegrity < 0.7) {
        freshnessScore *= 0.6; // Reduce score for shape distortions
      }

      // Generate decay indicators
      const decayIndicators: string[] = [];
      if (colorAnalysis.darkPixelRatio > 0.2) decayIndicators.push('Dark spots detected');
      if (colorAnalysis.colorVariance > 50) decayIndicators.push('Color inconsistency');
      if (textureAnalysis.smoothness < 0.6) decayIndicators.push('Surface irregularities');
      if (shapeAnalysis.irregularityScore > 0.3) decayIndicators.push('Shape deformation');
      if (rottenProb > 0.3) decayIndicators.push('AI model indicates decay');

      if (decayIndicators.length === 0) {
        decayIndicators.push('No visible decay indicators');
        decayIndicators.push('Good color retention');
        decayIndicators.push('Smooth surface texture');
      }

      // Determine quality grade
      let qualityGrade: string;
      if (freshnessScore > 0.8) qualityGrade = 'Grade A';
      else if (freshnessScore > 0.6) qualityGrade = 'Grade B';
      else if (freshnessScore > 0.4) qualityGrade = 'Grade C';
      else qualityGrade = 'Grade D';

      // Generate recommendations
      const recommendations: string[] = [];
      if (freshnessScore > 0.7) {
        recommendations.push('Suitable for retail sale');
        recommendations.push('Store in cool, dry place');
        recommendations.push('Use within recommended timeframe');
      } else if (freshnessScore > 0.4) {
        recommendations.push('Use for processing or cooking');
        recommendations.push('Consume within 1-2 days');
        recommendations.push('Check for further deterioration');
      } else {
        recommendations.push('Remove from batch immediately');
        recommendations.push('Dispose safely');
        recommendations.push('Check surrounding produce');
      }

      // Detect produce type (simplified)
      const produceType = this.detectProduceType(colorAnalysis);

      // Clean up tensors
      tensor.dispose();
      prediction.dispose();

      return {
        classification: freshnessScore > 0.5 ? 'fresh' : 'rotten',
        confidence: Math.max(freshProb, rottenProb),
        freshness_score: freshnessScore,
        decay_indicators: decayIndicators,
        quality_grade: qualityGrade,
        recommendations,
        produce_type: produceType
      };

    } catch (error) {
      console.error('Analysis failed:', error);
      throw error;
    }
  }

  private detectProduceType(colorAnalysis: any): string {
    const { r, g, b } = colorAnalysis.averageColor;
    
    // Simple color-based produce detection
    if (r > 150 && g < 100 && b < 100) return 'Apple/Tomato';
    if (r > 200 && g > 150 && b < 100) return 'Orange/Carrot';
    if (r > 150 && g > 200 && b < 100) return 'Banana/Lemon';
    if (r < 100 && g > 150 && b < 100) return 'Lettuce/Cabbage';
    if (r < 100 && g < 100 && b > 150) return 'Blueberry/Eggplant';
    
    return 'Mixed Produce';
  }

  isModelLoaded(): boolean {
    return this.isLoaded;
  }
}

export const aiService = new AIService();