import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  where,
  Timestamp,
  onSnapshot
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../config/firebase';

export interface AnalysisRecord {
  id?: string;
  imageUrl: string;
  classification: 'fresh' | 'rotten' | 'uncertain';
  confidence: number;
  freshness_score: number;
  decay_indicators: string[];
  quality_grade: string;
  recommendations: string[];
  processing_time: number;
  timestamp: Timestamp;
  produce_type?: string;
  user_feedback?: 'correct' | 'incorrect';
}

export interface DashboardStats {
  totalAnalyses: number;
  freshDetected: number;
  rottenDetected: number;
  averageAccuracy: number;
  todayAnalyses: number;
  weeklyGrowth: number;
}

class FirebaseService {
  // Upload image to Firebase Storage
  async uploadImage(imageBlob: Blob, filename: string): Promise<string> {
    const imageRef = ref(storage, `images/${filename}`);
    const snapshot = await uploadBytes(imageRef, imageBlob);
    return await getDownloadURL(snapshot.ref);
  }

  // Save analysis result to Firestore
  async saveAnalysis(analysisData: Omit<AnalysisRecord, 'id'>): Promise<string> {
    const docRef = await addDoc(collection(db, 'analyses'), {
      ...analysisData,
      timestamp: Timestamp.now()
    });
    return docRef.id;
  }

  // Get recent analyses
  async getRecentAnalyses(limitCount: number = 10): Promise<AnalysisRecord[]> {
    const q = query(
      collection(db, 'analyses'),
      orderBy('timestamp', 'desc'),
      limit(limitCount)
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as AnalysisRecord));
  }

  // Get analyses for a specific date range
  async getAnalysesByDateRange(startDate: Date, endDate: Date): Promise<AnalysisRecord[]> {
    const q = query(
      collection(db, 'analyses'),
      where('timestamp', '>=', Timestamp.fromDate(startDate)),
      where('timestamp', '<=', Timestamp.fromDate(endDate)),
      orderBy('timestamp', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as AnalysisRecord));
  }

  // Get dashboard statistics
  async getDashboardStats(): Promise<DashboardStats> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);

    // Get all analyses
    const allAnalysesQuery = query(collection(db, 'analyses'));
    const allAnalysesSnapshot = await getDocs(allAnalysesQuery);
    const allAnalyses = allAnalysesSnapshot.docs.map(doc => doc.data() as AnalysisRecord);

    // Get today's analyses
    const todayQuery = query(
      collection(db, 'analyses'),
      where('timestamp', '>=', Timestamp.fromDate(today))
    );
    const todaySnapshot = await getDocs(todayQuery);

    // Get last week's analyses
    const lastWeekQuery = query(
      collection(db, 'analyses'),
      where('timestamp', '>=', Timestamp.fromDate(weekAgo)),
      where('timestamp', '<', Timestamp.fromDate(today))
    );
    const lastWeekSnapshot = await getDocs(lastWeekQuery);

    const totalAnalyses = allAnalyses.length;
    const freshDetected = allAnalyses.filter(a => a.classification === 'fresh').length;
    const rottenDetected = allAnalyses.filter(a => a.classification === 'rotten').length;
    const todayAnalyses = todaySnapshot.size;
    const lastWeekAnalyses = lastWeekSnapshot.size;

    const averageAccuracy = allAnalyses.length > 0 
      ? allAnalyses.reduce((sum, a) => sum + a.confidence, 0) / allAnalyses.length * 100
      : 0;

    const weeklyGrowth = lastWeekAnalyses > 0 
      ? ((todayAnalyses - lastWeekAnalyses) / lastWeekAnalyses) * 100
      : 0;

    return {
      totalAnalyses,
      freshDetected,
      rottenDetected,
      averageAccuracy,
      todayAnalyses,
      weeklyGrowth
    };
  }

  // Real-time listener for analyses
  subscribeToAnalyses(callback: (analyses: AnalysisRecord[]) => void) {
    const q = query(
      collection(db, 'analyses'),
      orderBy('timestamp', 'desc'),
      limit(50)
    );

    return onSnapshot(q, (querySnapshot) => {
      const analyses = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as AnalysisRecord));
      callback(analyses);
    });
  }

  // Update user feedback
  async updateUserFeedback(analysisId: string, feedback: 'correct' | 'incorrect'): Promise<void> {
    const analysisRef = collection(db, 'analyses');
    await addDoc(analysisRef, { user_feedback: feedback });
  }
}

export const firebaseService = new FirebaseService();