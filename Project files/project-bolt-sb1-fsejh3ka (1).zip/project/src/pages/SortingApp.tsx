import React, { useState, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { 
  Upload, 
  Camera, 
  Play, 
  Pause, 
  RotateCcw, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Download,
  Eye,
  Zap
} from 'lucide-react';
import { useAI } from '../context/AIContext';
import ImageUpload from '../components/ImageUpload';
import CameraCapture from '../components/CameraCapture';
import ResultsDisplay from '../components/ResultsDisplay';
import ProcessingAnimation from '../components/ProcessingAnimation';

const SortingApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upload' | 'camera'>('upload');
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<any>(null);
  const { analyzeImage, isModelLoaded, isLoading, modelLoadError } = useAI();

  const handleImageAnalysis = useCallback(async (imageData: string) => {
    setIsProcessing(true);
    setResults(null);
    
    try {
      const analysisResults = await analyzeImage(imageData);
      setResults(analysisResults);
    } catch (error) {
      console.error('Analysis failed:', error);
      setResults({
        error: 'Analysis failed. Please try again.',
        confidence: 0,
        classification: 'error'
      });
    } finally {
      setIsProcessing(false);
    }
  }, [analyzeImage]);

  const resetAnalysis = () => {
    setResults(null);
    setIsProcessing(false);
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            AI-Powered Produce Sorting
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Upload images or use your camera to instantly analyze fruit and vegetable quality
          </p>
          
          {isLoading && (
            <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-md mx-auto">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-yellow-600" />
                <span className="text-yellow-800 font-medium">Loading AI Model...</span>
              </div>
            </div>
          )}

          {!isLoading && modelLoadError && (
            <div className="mt-6 bg-red-50 border border-red-200 rounded-lg p-4 max-w-md mx-auto">
              <div className="flex items-center space-x-2">
                <XCircle className="h-5 w-5 text-red-600" />
                <span className="text-red-800 font-medium">Model Loading Failed: {modelLoadError}</span>
              </div>
            </div>
          )}
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {/* Tab Navigation */}
          <motion.div 
            className="flex justify-center mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="bg-white rounded-lg p-1 shadow-lg">
              <button
                onClick={() => setActiveTab('upload')}
                className={`px-6 py-3 rounded-md font-medium transition-all duration-200 flex items-center space-x-2 ${
                  activeTab === 'upload'
                    ? 'bg-green-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                <Upload className="h-5 w-5" />
                <span>Upload Image</span>
              </button>
              <button
                onClick={() => setActiveTab('camera')}
                className={`px-6 py-3 rounded-md font-medium transition-all duration-200 flex items-center space-x-2 ${
                  activeTab === 'camera'
                    ? 'bg-green-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-green-600'
                }`}
              >
                <Camera className="h-5 w-5" />
                <span>Use Camera</span>
              </button>
            </div>
          </motion.div>

          {/* Main Content Area */}
          <motion.div
            className="bg-white rounded-2xl shadow-xl overflow-hidden"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {/* Input Section */}
            <div className="p-8">
              {activeTab === 'upload' ? (
                <ImageUpload 
                  onImageSelect={handleImageAnalysis}
                  disabled={!isModelLoaded || isProcessing}
                />
              ) : (
                <CameraCapture 
                  onCapture={handleImageAnalysis}
                  disabled={!isModelLoaded || isProcessing}
                />
              )}
            </div>

            {/* Processing Animation */}
            {isProcessing && (
              <div className="border-t border-gray-100 p-8">
                <ProcessingAnimation />
              </div>
            )}

            {/* Results Section */}
            {results && !isProcessing && (
              <div className="border-t border-gray-100 p-8">
                <ResultsDisplay 
                  results={results} 
                  onReset={resetAnalysis}
                />
              </div>
            )}

            {/* Action Buttons */}
            {(results || isProcessing) && (
              <div className="border-t border-gray-100 p-6 bg-gray-50 flex justify-center space-x-4">
                <button
                  onClick={resetAnalysis}
                  className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors flex items-center space-x-2"
                  disabled={isProcessing}
                >
                  <RotateCcw className="h-5 w-5" />
                  <span>Analyze Another</span>
                </button>
                
                {results && !results.error && (
                  <button
                    onClick={() => {
                      const dataStr = JSON.stringify(results, null, 2);
                      const dataBlob = new Blob([dataStr], { type: 'application/json' });
                      const url = URL.createObjectURL(dataBlob);
                      const link = document.createElement('a');
                      link.href = url;
                      link.download = 'analysis-results.json';
                      link.click();
                    }}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
                  >
                    <Download className="h-5 w-5" />
                    <span>Download Results</span>
                  </button>
                )}
              </div>
            )}
          </motion.div>

          {/* Features Grid */}
          <motion.div
            className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="bg-green-100 p-3 rounded-full w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Eye className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Advanced Vision</h3>
              <p className="text-gray-600 text-sm">Deep learning models trained on thousands of produce images</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="bg-blue-100 p-3 rounded-full w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Zap className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Instant Results</h3>
              <p className="text-gray-600 text-sm">Get quality assessment results in seconds</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <div className="bg-orange-100 p-3 rounded-full w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">High Accuracy</h3>
              <p className="text-gray-600 text-sm">99%+ accuracy in detecting rotten produce</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default SortingApp;