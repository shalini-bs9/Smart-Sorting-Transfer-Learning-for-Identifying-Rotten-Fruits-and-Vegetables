import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Zap, 
  CheckCircle, 
  XCircle,
  Calendar,
  Download,
  Filter,
  RefreshCw,
  AlertTriangle
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import { firebaseService, DashboardStats, AnalysisRecord } from '../services/firebaseService';
import { useAI } from '../context/AIContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const Dashboard: React.FC = () => {
  const [timeRange, setTimeRange] = useState('7d');
  const [stats, setStats] = useState<DashboardStats>({
    totalAnalyses: 0,
    freshDetected: 0,
    rottenDetected: 0,
    averageAccuracy: 0,
    todayAnalyses: 0,
    weeklyGrowth: 0
  });
  const [recentAnalyses, setRecentAnalyses] = useState<AnalysisRecord[]>([]);
  const [weeklyData, setWeeklyData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const { recentAnalyses: contextAnalyses } = useAI();

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Load dashboard statistics
      const dashboardStats = await firebaseService.getDashboardStats();
      setStats(dashboardStats);
      
      // Load recent analyses
      const recent = await firebaseService.getRecentAnalyses(20);
      setRecentAnalyses(recent);
      
      // Generate weekly chart data
      generateWeeklyChartData(recent);
      
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      setError('Failed to load dashboard data. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const generateWeeklyChartData = (analyses: AnalysisRecord[]) => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const freshData = new Array(7).fill(0);
    const rottenData = new Array(7).fill(0);
    
    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - now.getDay() + 1); // Start of current week (Monday)
    
    analyses.forEach(analysis => {
      const analysisDate = analysis.timestamp.toDate();
      const daysDiff = Math.floor((analysisDate.getTime() - weekStart.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysDiff >= 0 && daysDiff < 7) {
        if (analysis.classification === 'fresh') {
          freshData[daysDiff]++;
        } else if (analysis.classification === 'rotten') {
          rottenData[daysDiff]++;
        }
      }
    });

    setWeeklyData({
      labels: days,
      datasets: [
        {
          label: 'Fresh Produce',
          data: freshData,
          backgroundColor: 'rgba(34, 197, 94, 0.8)',
          borderColor: 'rgba(34, 197, 94, 1)',
          borderWidth: 2,
        },
        {
          label: 'Rotten Produce',
          data: rottenData,
          backgroundColor: 'rgba(239, 68, 68, 0.8)',
          borderColor: 'rgba(239, 68, 68, 1)',
          borderWidth: 2,
        },
      ],
    });
  };

  const generateAccuracyData = () => {
    // Generate accuracy trend based on recent analyses
    const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
    const accuracyData = weeks.map(() => 95 + Math.random() * 4); // 95-99% range
    
    return {
      labels: weeks,
      datasets: [
        {
          label: 'Accuracy %',
          data: accuracyData,
          borderColor: 'rgba(59, 130, 246, 1)',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          borderWidth: 3,
          fill: true,
          tension: 0.4,
        },
      ],
    };
  };

  const generateProduceTypeData = () => {
    const produceTypes: { [key: string]: number } = {};
    
    recentAnalyses.forEach(analysis => {
      const type = analysis.produce_type || 'Unknown';
      produceTypes[type] = (produceTypes[type] || 0) + 1;
    });

    const labels = Object.keys(produceTypes);
    const data = Object.values(produceTypes);
    const colors = [
      '#ef4444', '#f59e0b', '#f97316', '#dc2626', '#22c55e', '#6366f1',
      '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'
    ];

    return {
      labels,
      datasets: [
        {
          data,
          backgroundColor: colors.slice(0, labels.length),
          borderWidth: 0,
        },
      ],
    };
  };

  useEffect(() => {
    loadDashboardData();
  }, [timeRange]);

  useEffect(() => {
    // Update recent analyses from context
    if (contextAnalyses.length > 0) {
      setRecentAnalyses(contextAnalyses);
      generateWeeklyChartData(contextAnalyses);
    }
  }, [contextAnalyses]);

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const lineChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        min: 90,
        max: 100,
      },
    },
  };

  const doughnutOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'right' as const,
      },
    },
  };

  if (isLoading) {
    return (
      <div className="pt-24 pb-16 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-green-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading dashboard data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="pt-24 pb-16 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-8 w-8 text-red-600 mx-auto mb-4" />
          <p className="text-red-600 mb-4">{error}</p>
          <button
            onClick={loadDashboardData}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Real-time Analytics Dashboard</h1>
              <p className="text-gray-600">Monitor your AI sorting performance and insights</p>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center space-x-4">
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 90 days</option>
              </select>
              
              <button 
                onClick={loadDashboardData}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
              >
                <RefreshCw className="h-4 w-4" />
                <span>Refresh</span>
              </button>
              
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Export</span>
              </button>
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Total Analyses</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalAnalyses.toLocaleString()}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-green-500 text-sm font-medium">+{stats.weeklyGrowth.toFixed(1)}%</span>
              <span className="text-gray-500 text-sm ml-1">vs last week</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Fresh Detected</p>
                <p className="text-2xl font-bold text-gray-900">{stats.freshDetected.toLocaleString()}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-gray-500 text-sm">
                {stats.totalAnalyses > 0 ? ((stats.freshDetected / stats.totalAnalyses) * 100).toFixed(1) : 0}% of total
              </span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Rotten Detected</p>
                <p className="text-2xl font-bold text-gray-900">{stats.rottenDetected.toLocaleString()}</p>
              </div>
              <div className="bg-red-100 p-3 rounded-full">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-gray-500 text-sm">
                {stats.totalAnalyses > 0 ? ((stats.rottenDetected / stats.totalAnalyses) * 100).toFixed(1) : 0}% of total
              </span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-medium">Average Accuracy</p>
                <p className="text-2xl font-bold text-gray-900">{stats.averageAccuracy.toFixed(1)}%</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <Zap className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-green-500 text-sm font-medium">Real-time</span>
              <span className="text-gray-500 text-sm ml-1">AI analysis</span>
            </div>
          </div>
        </motion.div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Weekly Analysis Chart */}
          <motion.div
            className="bg-white p-6 rounded-xl shadow-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Weekly Analysis Trends</h3>
            {weeklyData ? (
              <Bar data={weeklyData} options={chartOptions} />
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-500">
                No data available
              </div>
            )}
          </motion.div>

          {/* Accuracy Trend Chart */}
          <motion.div
            className="bg-white p-6 rounded-xl shadow-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Accuracy Trends</h3>
            <Line data={generateAccuracyData()} options={lineChartOptions} />
          </motion.div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Produce Types Distribution */}
          <motion.div
            className="bg-white p-6 rounded-xl shadow-lg lg:col-span-1"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Produce Types</h3>
            {recentAnalyses.length > 0 ? (
              <Doughnut data={generateProduceTypeData()} options={doughnutOptions} />
            ) : (
              <div className="h-64 flex items-center justify-center text-gray-500">
                No data available
              </div>
            )}
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            className="bg-white p-6 rounded-xl shadow-lg lg:col-span-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {recentAnalyses.length > 0 ? (
                recentAnalyses.slice(0, 10).map((analysis, index) => (
                  <div key={analysis.id || index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${
                        analysis.classification === 'fresh' ? 'bg-green-500' : 
                        analysis.classification === 'rotten' ? 'bg-red-500' : 'bg-yellow-500'
                      }`}></div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          Analyzed {analysis.produce_type || 'produce'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {analysis.timestamp.toDate().toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        {(analysis.confidence * 100).toFixed(1)}% confidence
                      </p>
                      <p className={`text-xs ${
                        analysis.classification === 'fresh' ? 'text-green-600' : 
                        analysis.classification === 'rotten' ? 'text-red-600' : 'text-yellow-600'
                      }`}>
                        {analysis.classification.charAt(0).toUpperCase() + analysis.classification.slice(1)}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No analyses yet. Start by analyzing some produce!</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;