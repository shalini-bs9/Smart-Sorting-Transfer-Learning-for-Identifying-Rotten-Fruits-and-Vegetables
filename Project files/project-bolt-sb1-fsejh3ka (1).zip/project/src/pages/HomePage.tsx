import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Brain, 
  Camera, 
  CheckCircle, 
  Factory, 
  Home, 
  Shield, 
  Smartphone, 
  Store, 
  Zap,
  ArrowRight,
  Eye,
  Cpu,
  BarChart3,
  Play
} from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="pt-20 pb-16 bg-gradient-to-br from-green-50 via-blue-50 to-orange-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <motion.div 
              className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Zap className="h-4 w-4" />
              <span>Artificial Intelligence</span>
            </motion.div>
            
            <motion.h1 
              className="text-4xl md:text-6xl font-bold text-gray-900 mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              Smart Sorting: Transfer Learning for 
              <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent"> Identifying Rotten</span> Fruits and Vegetables
            </motion.h1>
            
            <motion.p 
              className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              Revolutionizing agricultural quality control with cutting-edge transfer learning techniques. 
              Enhance precision and efficiency in detecting rotten produce using deep learning models.
            </motion.p>

            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Link
                to="/app"
                className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 flex items-center space-x-2 group"
              >
                <Play className="h-5 w-5 group-hover:scale-110 transition-transform" />
                <span>Try AI Sorting Now</span>
              </Link>
              <Link
                to="/dashboard"
                className="bg-white text-gray-700 px-8 py-4 rounded-lg font-semibold border border-gray-200 hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
              >
                <BarChart3 className="h-5 w-5" />
                <span>View Analytics</span>
              </Link>
            </motion.div>

            <motion.div 
              className="bg-white p-8 rounded-2xl shadow-xl max-w-4xl mx-auto"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="bg-green-100 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <BarChart3 className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">99% Accuracy</h3>
                  <p className="text-gray-600 text-sm">Precise detection of rotten produce</p>
                </div>
                <div className="text-center">
                  <div className="bg-blue-100 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <Zap className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Real-time Processing</h3>
                  <p className="text-gray-600 text-sm">Instant quality assessment</p>
                </div>
                <div className="text-center">
                  <div className="bg-orange-100 p-3 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <Shield className="h-8 w-8 text-orange-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Food Safety</h3>
                  <p className="text-gray-600 text-sm">Ensuring quality standards</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Scenarios Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Real-World Applications
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover how Smart Sorting transforms quality control across different industries
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Factory,
                title: "Food Processing Plant",
                description: "Automate the sorting process in large food processing facilities. Cameras on conveyor belts capture images while AI instantly identifies and removes rotten produce, eliminating human error and dramatically increasing throughput efficiency.",
                features: ["Automated Sorting", "High Throughput"],
                color: "green"
              },
              {
                icon: Store,
                title: "Supermarket Quality Control",
                description: "Deploy real-time scanning at receiving docks to ensure only fresh produce reaches store shelves. Maintain customer satisfaction and store reputation while significantly reducing waste and inventory losses.",
                features: ["Real-time Scanning", "Waste Reduction"],
                color: "blue"
              },
              {
                icon: Home,
                title: "Smart Home Integration",
                description: "Smart refrigerators with integrated cameras continuously monitor stored produce. Receive smartphone alerts when items start deteriorating, helping families reduce food waste and manage groceries more effectively.",
                features: ["Smart Alerts", "App Integration"],
                color: "orange"
              }
            ].map((scenario, index) => (
              <motion.div
                key={index}
                className={`bg-gradient-to-br from-${scenario.color}-50 to-${scenario.color}-100 p-8 rounded-2xl hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <div className={`bg-${scenario.color}-500 p-4 rounded-full w-16 h-16 mb-6 flex items-center justify-center`}>
                  <scenario.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{scenario.title}</h3>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  {scenario.description}
                </p>
                <div className="flex items-center space-x-4 text-sm">
                  {scenario.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className={`flex items-center space-x-1 text-${scenario.color}-600`}>
                      <CheckCircle className="h-4 w-4" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Cutting-Edge Features
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Advanced transfer learning capabilities that set new standards in agricultural AI
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Camera, title: "Computer Vision", description: "Advanced image recognition powered by deep neural networks", color: "green" },
              { icon: Brain, title: "Transfer Learning", description: "Pre-trained models adapted for produce quality assessment", color: "blue" },
              { icon: Zap, title: "Real-time Processing", description: "Instant analysis and decision making for continuous operation", color: "orange" },
              { icon: Smartphone, title: "Smart Integration", description: "Seamless connectivity with existing systems and mobile apps", color: "purple" }
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <feature.icon className={`h-10 w-10 text-${feature.color}-500 mb-4`} />
                <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Technology Stack
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Built with industry-leading technologies for maximum performance and reliability
            </p>
          </motion.div>

          <motion.div 
            className="bg-gradient-to-r from-green-50 to-blue-50 p-8 rounded-2xl"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Core Technologies</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="bg-green-500 p-2 rounded-lg">
                      <Cpu className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">TensorFlow.js</h4>
                      <p className="text-gray-600 text-sm">Machine learning in the browser</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="bg-blue-500 p-2 rounded-lg">
                      <Brain className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">Deep Learning</h4>
                      <p className="text-gray-600 text-sm">Neural networks for pattern recognition</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Key Capabilities</h3>
                <div className="space-y-3">
                  {[
                    "Transfer learning implementation",
                    "Image preprocessing and augmentation",
                    "Model optimization and deployment",
                    "Real-time inference systems"
                  ].map((capability, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <ArrowRight className="h-4 w-4 text-green-500" />
                      <span className="text-gray-700">{capability}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to Transform Your Quality Control?
            </h2>
            <p className="text-xl text-green-100 mb-8">
              Join the agricultural revolution with AI-powered produce sorting technology
            </p>
            <Link
              to="/app"
              className="bg-white text-green-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors shadow-lg inline-flex items-center space-x-2"
            >
              <Play className="h-5 w-5" />
              <span>Get Started Today</span>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center space-x-2 mb-8">
            <div className="bg-gradient-to-r from-green-500 to-blue-500 p-2 rounded-lg">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold text-white">Smart Sorting AI</span>
          </div>
          <p className="text-center text-gray-400">
            © 2025 Smart Sorting AI. Revolutionizing agricultural quality control with artificial intelligence.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;